# Unused Original Dex References

This folder contains references to the original Dex project for archival purposes only.

## Original Project Information
- **Original Name**: Dex - The Freedom Explorer
- **Original Developer**: LorekeeperZinnia (Moon)
- **Original Repository**: LorekeeperZinnia/Dex

## Notes
- These files are kept for reference and attribution purposes
- All active code has been rebranded to h1iy Hub
- No original Dex code is used in the main project
- This is purely for documentation and credit preservation