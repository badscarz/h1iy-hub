# h1iy Hub - The Freedom Explorer
![Logo](/logo.png)

## Intro
h1iy Hub is a powerful debugging suite designed to help users debug games and find potential vulnerabilities.

Witness the most powerful explorer to have ever existed. Bringing unlimited freedom to everyone who has used it. Exploring places that have never been explored before.

You are encouraged to edit, fork, do whatever with this. Feel free to customize and enhance it for your needs.

This project is provided in file format to make it easier for anyone who wants to continue or edit this. Build instructions are below.

## Setup Instructions for badscarz

### Creating Your GitHub Repository
1. Go to https://github.com/new
2. Repository name: `h1iy-hub`
3. Make sure to initialize with a README
4. Choose Public or Private as needed
5. Click "Create repository"

### Setting Up on Your Local Machine
1. Clone the repository:
```bash
git clone https://github.com/badscarz/h1iy-hub.git
cd h1iy-hub
```

2. Copy all files from this zip to the repository folder
3. Commit and push:
```bash
git add .
git commit -m "Initial commit: h1iy Hub"
git push origin main
```

### Link Placeholders to Edit
You'll need to update these links throughout the project:

**In main.lua:**
- Line with `Main.GitRepoName` - Change to: `"badscarz/h1iy-hub"`
- Discord server link - Replace with your community server

**In README.md:**
- Update all references to your repository
- Add your Discord server link below

## Notes
- There is no cloneref protection, add it if you want
- It may be detected by more stuff; I don't know what these detections are nor am I interested in fixing it
- Some stuff can be optimized further (ex: explorer node add/remove), it's up to you if you want to do it
- Some stuff may break when roblox releases deferred events. Ex: Selecting a duplicated instance

## To Build
1. Ensure you have Python 3 (I use 3.9.0)
2. Run build.py
3. The executable script will be created as out.lua

## High Level Roadmap
List of stuff that could be added to make h1iy Hub the ultimate utility:
- Terminal
	* basically command interface with useful commands (non troll or gross) to get around
	* each command has all its funcs, state contained in a table
- Debugging interface
	* more than just a remotespy
	* you can choose to hook any metamethod, instance func/prop/event/callback, or any func
	* logging args/returns of those funcs (like a remotespy)
	* realtime editing of your hooks (allowing easy debugging: arg apoofing, return spoofing, unhook) using script editor
	* scripted filters
	* save/load these configs
	* default template would be set up to function like a remotespy
- Explorer
	* smart autofill for search
	* more filters for search
	* bookmarking / starring insts
	* a lot of the things in right click that i planned but didn't finish
- Properties
	* Copy value on clipboard (what is displayed in the box, or formatted to be pasted into lua)
	* Select object properties in explorer
	* Tag Editor (I saw the new one on devforum recently, would be better as its own window)
- Data viewing & finding
	* the const, upval, etc searching
	* list references of userdata, table, function (i wanted to make it so you can easily explore the references, opens new tab for each individual object)
	* detailed view of selected function (env, consts, upvals, decompiled src, script path, references)
	* easily create constant signatures
	* thread exploring
- Script viewer/editor
	* some decent autofill
	* info bar at bottom (line of error, line count, col count, etc)
- Reference
	* interactive api docs for instance props, funcs, etc
	* docs for some other stuff such as 'h1iy' global, plugin api, executor api, etc
	* some tutorials with text, pics, and video (not doing video until roblox removes limit of 3 playing videos)
- Plugins
	* Easy way to add some stuff such as right click options, search filters, commands, etc
	* Access to h1iy's api for windows, modules, etc

## Missing features
Features that could be added if you plan to continue / edit this.
- Click to select
- Saving (instance specific in right click menu, and a menu for whole map saving)
- Settings menu
- Tabs in script viewer

## Community Server
Join the community server for more information and support:<br>
[PLACEHOLDER: Your Discord Server Link Here]<br>

Note that support availability may vary.

## License
This project is licensed under the MIT License.